<?php
$verbose = FALSE; // Set to TRUE if you don't want to display invalid code coupons
$prefix = array(
	[
		"ZX8", // set prefix
		5 // random digits are used after prefix (e.g: ZX8_____)
	],
	// [
	// 	"COY",
	// 	5 
	// ]
);