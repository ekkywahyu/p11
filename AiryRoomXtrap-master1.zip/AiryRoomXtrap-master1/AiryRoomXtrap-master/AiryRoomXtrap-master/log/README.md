Results of valid coupon codes will be shown here as log file.
